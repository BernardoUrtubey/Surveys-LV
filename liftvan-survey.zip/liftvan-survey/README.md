# Lift Van International — Survey Report Generator

Generador de informes de survey en PDF (español + inglés) con diseño oficial de Lift Van International.

---

## Estructura del proyecto

```
liftvan-survey/
├── backend/          ← API Flask (genera los PDFs)
│   ├── app.py
│   ├── pdf_generator.py
│   ├── logo_color_transp.png
│   ├── logo_wm_final.png
│   ├── requirements.txt
│   └── Procfile
└── frontend/         ← Formulario web
    └── index.html
```

---

## Deployment paso a paso

### 1. Subir a GitHub

1. Crear cuenta en [github.com](https://github.com) si no tenés
2. Crear un repositorio nuevo llamado `liftvan-survey`
3. Subir esta carpeta completa al repositorio

### 2. Backend en Render (gratuito)

1. Ir a [render.com](https://render.com) y crear cuenta
2. Click en **New → Web Service**
3. Conectar el repositorio de GitHub
4. Configurar:
   - **Name**: `liftvan-survey-api`
   - **Root Directory**: `backend`
   - **Runtime**: Python 3
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn app:app`
5. Click **Create Web Service**
6. Esperar que termine el deploy (2-3 min)
7. Copiar la URL que te da Render (ej: `https://liftvan-survey-api.onrender.com`)

### 3. Actualizar la URL en el frontend

En `frontend/index.html`, buscar esta línea:
```javascript
const BACKEND_URL = 'https://liftvan-survey-api.onrender.com';
```
Y reemplazarla con la URL real de tu backend en Render.

### 4. Frontend en Vercel (gratuito)

1. Ir a [vercel.com](https://vercel.com) y crear cuenta con GitHub
2. Click en **New Project**
3. Importar el repositorio `liftvan-survey`
4. Configurar:
   - **Root Directory**: `frontend`
   - Framework: Other
5. Click **Deploy**
6. En 1 minuto tenés la URL lista para compartir

---

## Uso

1. Abrir la URL de Vercel en cualquier navegador
2. Completar los datos del cliente
3. Agregar ambientes e ítems
4. Click en **Descargar en Español** o **Descargar en English**
5. El PDF se descarga automáticamente

---

## Soporte
sales@liftvan.com
